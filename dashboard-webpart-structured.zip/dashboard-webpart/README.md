# Dashboard Web Part for SharePoint Framework

## Overview
A comprehensive dashboard web part built with SharePoint Framework (SPFx) 1.23.2 featuring multiple sections for displaying organizational information, news, sales data, and more.

## Features
- **Icon Carousel**: Display featured icons/quick links
- **Content Query**: Query and display content from SharePoint lists
- **Notices**: Display important announcements and notices
- **News Carousel**: Showcase latest news and articles
- **Sales Performance Data**: Table view with sales metrics
- **Responsive Design**: Mobile-friendly layout

## Project Structure

```
src/
├── webparts/
│   └── dashboard/
│       ├── DashboardWebPart.ts          # Main web part class
│       ├── DashboardWebPart.manifest.json # Web part manifest
│       ├── components/
│       │   ├── Dashboard.tsx            # Main component
│       │   ├── Dashboard.module.scss    # Main styles
│       │   ├── IDashboardProps.ts       # Props interface
│       │   ├── sections/
│       │   │   ├── IconCarousel.tsx
│       │   │   ├── IconCarousel.module.scss
│       │   │   ├── ContentQuery.tsx
│       │   │   ├── ContentQuery.module.scss
│       │   │   ├── Notices.tsx
│       │   │   ├── Notices.module.scss
│       │   │   ├── NewsCarousel.tsx
│       │   │   ├── NewsCarousel.module.scss
│       │   │   ├── SalesPerformance.tsx
│       │   │   └── SalesPerformance.module.scss
│       └── loc/
│           └── en-us.js                 # Localization strings
├── index.ts
├── tsconfig.json
└── config.json                          # SPFx configuration

Files Generated:
- DashboardWebPart.ts
- DashboardWebPart.manifest.json
- config.json
- package.json
- tsconfig.json
- Dashboard.tsx
- IDashboardProps.ts
- Component files (IconCarousel, ContentQuery, Notices, NewsCarousel, SalesPerformance)
- SCSS module files for styling
- en-us.js (localization strings)
```

## Requirements
- Node.js: >= 22.14.0 < 23.0.0
- SharePoint Framework: 1.23.2
- TypeScript: ~5.8.0
- npm: >= 9.0.0

## Installation

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Build the project**:
   ```bash
   npm run build
   ```

3. **Bundle the solution**:
   ```bash
   npm run bundle
   ```

4. **Package the solution**:
   ```bash
   npm run package-solution
   ```

## Development

1. **Start development server**:
   ```bash
   npm run serve
   ```

2. **Run tests**:
   ```bash
   npm run test
   ```

3. **Clean build artifacts**:
   ```bash
   npm run clean
   ```

## Configuration

### Web Part Properties
Edit the property pane in `DashboardWebPart.ts` to customize:
- **Title**: Web part display name
- **Description**: Web part description

### Styling
Modify SCSS files in each component's `.module.scss` file:
- Colors
- Spacing
- Typography
- Responsive breakpoints

## Component Details

### Dashboard (Main Component)
- Orchestrates all sub-components
- Manages layout (2-column grid)
- Renders header with notification

### Sections
- **IconCarousel**: Placeholder for icon-based navigation
- **ContentQuery**: Query SharePoint content
- **Notices**: Display announcements
- **NewsCarousel**: Carousel for news items
- **SalesPerformance**: Data table with sales metrics

## Deployment

1. Upload `.sppkg` file to SharePoint App Catalog
2. Approve the app
3. Add web part to a SharePoint page
4. Configure properties as needed

## Localization

Add additional language support by creating language files in `src/loc/`:
- `en-us.js` (English - included)
- `fr-fr.js` (French)
- `de-de.js` (German)
- etc.

## Browser Support
- Chrome (latest)
- Edge (latest)
- Safari (latest)
- Firefox (latest)

## Troubleshooting

### Build Errors
- Clear node_modules and reinstall: `rm -rf node_modules && npm install`
- Update npm: `npm install -g npm@latest`

### Runtime Issues
- Check browser console for errors
- Verify SharePoint site permissions
- Check network requests in DevTools

## Contributing
1. Create a feature branch
2. Make changes
3. Test thoroughly
4. Create a pull request

## License
MIT

## Support
For issues or questions, please contact your SharePoint administrator.
