import * as React from 'react';
import styles from './SalesPerformance.module.scss';

const SalesPerformance: React.FC = () => {
  const data = [
    { category: 'Category 1', titles: 'Title 1', lastUpdated: '2026-09-23', updater: 'User 1' },
    { category: 'Category 2', titles: 'Title 2', lastUpdated: '2026-09-22', updater: 'User 2' },
  ];

  return (
    <div className={styles.salesPerformance}>
      <table className={styles.table}>
        <thead>
          <tr>
            <th>Category</th>
            <th>Titles</th>
            <th>Last Updated</th>
            <th>Updater</th>
          </tr>
        </thead>
        <tbody>
          {data.map((row, index) => (
            <tr key={index}>
              <td>{row.category}</td>
              <td>{row.titles}</td>
              <td>{row.lastUpdated}</td>
              <td>{row.updater}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default SalesPerformance;
