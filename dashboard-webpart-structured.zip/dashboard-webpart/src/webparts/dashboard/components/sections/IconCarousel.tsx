import * as React from 'react';
import styles from './IconCarousel.module.scss';

const IconCarousel: React.FC = () => {
  return (
    <div className={styles.iconCarousel}>
      <div className={styles.placeholder}>Icon Carousel Content</div>
    </div>
  );
};

export default IconCarousel;
