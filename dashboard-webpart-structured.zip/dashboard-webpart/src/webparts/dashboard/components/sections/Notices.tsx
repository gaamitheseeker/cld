import * as React from 'react';
import styles from './Notices.module.scss';

const Notices: React.FC = () => {
  return (
    <div className={styles.notices}>
      <div className={styles.placeholder}>Notices</div>
    </div>
  );
};

export default Notices;
