import * as React from 'react';
import styles from './NewsCarousel.module.scss';

const NewsCarousel: React.FC = () => {
  return (
    <div className={styles.newsCarousel}>
      <div className={styles.placeholder}>News Carousel</div>
    </div>
  );
};

export default NewsCarousel;
