import * as React from 'react';
import styles from './ContentQuery.module.scss';

const ContentQuery: React.FC = () => {
  return (
    <div className={styles.contentQuery}>
      <div className={styles.placeholder}>Content Query</div>
    </div>
  );
};

export default ContentQuery;
