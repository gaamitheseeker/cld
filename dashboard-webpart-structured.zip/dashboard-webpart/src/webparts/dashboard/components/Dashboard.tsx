import * as React from 'react';
import styles from './Dashboard.module.scss';
import { IDashboardProps } from './IDashboardProps';
import IconCarousel from './sections/IconCarousel';
import ContentQuery from './sections/ContentQuery';
import Notices from './sections/Notices';
import NewsCarousel from './sections/NewsCarousel';
import SalesPerformance from './sections/SalesPerformance';

const Dashboard: React.FC<IDashboardProps> = (props) => {
  return (
    <div className={styles.dashboard}>
      <div className={styles.header}>
        <div className={styles.notification}>
          <p>2026年初営業開始PR画面ご報告は こちら</p>
          <p>以下のアイコンからAPC システムへのアクセスはこちらのページからアクセスしてください。APCシステムにアクセス</p>
        </div>
      </div>

      <div className={styles.container}>
        <div className={styles.leftColumn}>
          <div className={styles.section}>
            <h2>ICON CAROUSEL</h2>
            <IconCarousel />
          </div>

          <div className={styles.section}>
            <h2>CONTENT QUERY</h2>
            <ContentQuery />
          </div>

          <div className={styles.section}>
            <h2>NOTICES</h2>
            <Notices />
          </div>
        </div>

        <div className={styles.rightColumn}>
          <div className={styles.section}>
            <h2>NEWS AND FEATURED ARTICLES</h2>
            <div className={styles.newsContainer}>
              <div className={styles.carouselSection}>
                <h3>CAROUSEL</h3>
                <NewsCarousel />
              </div>

              <div className={styles.updateSection}>
                <div className={styles.updateHeader}>
                  <span>UPDATE</span>
                  <span>DATE OF EVENT</span>
                </div>
              </div>

              <div className={styles.salesSection}>
                <h3>SALES PERFORMANCE DATA</h3>
                <SalesPerformance />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
