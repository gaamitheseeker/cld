import { WebPartContext } from '@microsoft/sp-webpart-base';

export interface IDashboardProps {
  title: string;
  description: string;
  context: WebPartContext;
}
