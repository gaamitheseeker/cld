define([], function() {
  return {
    "PropertyPaneDescription": "Dashboard Web Part Configuration",
    "BasicGroupName": "General Settings",
    "TitleFieldLabel": "Web Part Title",
    "DescriptionFieldLabel": "Web Part Description"
  }
});
